-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Mar 24, 2023 at 09:59 AM
-- Server version: 10.3.38-MariaDB-0ubuntu0.20.04.1
-- PHP Version: 8.0.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `school`
--

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(190) NOT NULL,
  `email` varchar(190) NOT NULL,
  `rollno` varchar(7) NOT NULL,
  `class` tinyint(3) UNSIGNED NOT NULL,
  `photo` varchar(190) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`id`, `name`, `email`, `rollno`, `class`, `photo`, `created_at`, `updated_at`) VALUES
(2, 'Shivam  Sharma', 'shivam@gmail.com', '1234567', 4, 'uploads/641aae2f2fa6fowdjKWk - Imgur.jpg', '2023-03-23 06:48:35', '2023-03-23 06:50:28'),
(4, 'Naseem', 'naseem@gmail.com', '1234567', 4, 'uploads/641aae2f2fa6fowdjKWk - Imgur.jpg', '2023-03-23 07:34:39', '2023-03-23 07:34:39'),
(5, 'Naseem', 'naseem@gmail.com', '1234567', 4, 'uploads/641aae2f2fa6fowdjKWk - Imgur.jpg', '2023-03-23 07:36:04', '2023-03-23 07:36:04'),
(6, 'Naseem', 'naseem@gmail.com', '1234567', 4, 'uploads/641aae2f2fa6fowdjKWk - Imgur.jpg', '2023-03-23 07:36:20', '2023-03-23 07:36:20'),
(7, 'test', 'test222@gmail.com', '1234567', 6, 'uploads/641c188939a7bO0ckJJ4 - Imgur.jpg', '2023-03-23 09:14:49', '2023-03-23 09:14:49'),
(8, 'naseem', 'naseem@martvalley.com', '1234567', 10, 'uploads/641d22e92ae39381 (33).jpg', '2023-03-24 04:11:21', '2023-03-24 04:11:21'),
(9, 'naseem', 'naseem@martvalley.com', '1234567', 10, 'uploads/641d247c71b6f381 (33).jpg', '2023-03-24 04:18:04', '2023-03-24 04:18:04');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
